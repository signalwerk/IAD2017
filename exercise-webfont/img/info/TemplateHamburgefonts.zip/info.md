1. Oberkant Oberlänge überragt Versalhöhe
2. Doppelstöckiges (Zweistöckiges) a mit schrägem Anstrich
3. Offener Punzen
4. Dreistöckiges g mit geradem Ohr (Fähnchen)
5. Gerader Abstrich beim e
6. Verkürzte Oberlänge beim t